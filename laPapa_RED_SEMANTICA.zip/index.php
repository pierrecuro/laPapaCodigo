<?php  
require_once("Conexion.php");

/*Variables de Session*/
session_start();

$_SESSION=array();

$_SESSION["sin"]="0";
$_SESSION["h"]="0";
$_SESSION["id"]="1";
$_SESSION["desc"]="";
$_SESSION["x"]="0";
$_SESSION["cont"]="0";
$_SESSION["enf"]="";
$_SESSION["inicio"]="no";
?>



<!DOCTYPE html> 
<html lang="es">
<head>

<meta charset="ISO-8859-1">


<title>Sistema Experto</title>
<link rel='stylesheet' href='estilo_Pag.css'>
</head>

<body>
<div id="Cont">
<center>
  <p>&nbsp;</p>
  <h1>SISTEMA EXPERTO PARA LA DETECCION DE PLAGAS EN LA PAPA</h1>
  <table width="200" border="0">
    <tr>
      <td><center>
        <a href="Sintomas.php"><h1>Sintomas</h1></a>
      </center></td>
      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
      <td><center>
        <a href="Enfermedad.php"><h1>Plagas</h1></a>
      </center></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</center></div>
</body>
</html>
